
README.txt
==========

1- Enable local and content translation modules.
2- Add another language (e.g. Arabic).
2- Go to Language Switcher config page (admin/config/regional/language/language_switcher), select what mode you want to use.
3- Add nodes, add translations.
4- From blocks page select Language Switcher block and put it in sidebar for example.
5- Go back to the home page, the language switcher block now is clickable not just links, you should see nodes flying over there!